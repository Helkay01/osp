// Universal injector function using the modern browser fetch API
function injectComponent(targetId, sourceFile) {
  fetch(sourceFile)
    .then(response => {
      if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
      return response.text();
    })
    .then(htmlContent => {
      document.getElementById(targetId).innerHTML = htmlContent;
    })
    .catch(error => console.error(`Error loading ${sourceFile}:`, error));
}

// Run layout construction immediately when DOM is safe
document.addEventListener("DOMContentLoaded", () => {
  injectComponent("global-header", "header.html");
  injectComponent("global-footer", "footer.html");
});
